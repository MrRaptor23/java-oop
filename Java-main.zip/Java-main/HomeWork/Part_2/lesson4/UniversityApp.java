package HomeWork.Part_2.lesson4;

public class UniversityApp {}
