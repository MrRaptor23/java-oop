package HomeWork.Part_2.D_FruitBox;

public class Orange extends Fruit{
    public Orange(int weight) {
        super(weight);
    }
}
