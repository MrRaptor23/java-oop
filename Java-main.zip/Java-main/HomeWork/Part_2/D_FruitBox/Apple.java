package HomeWork.Part_2.D_FruitBox;

public class Apple extends Fruit{
    public Apple(int weight) {
        super(weight);
    }
}
