package HomeWork.Part_2.D_FruitBox;

public class GoldenApple extends Apple{
    public GoldenApple(int weight) {
        super(weight);
    }
}
