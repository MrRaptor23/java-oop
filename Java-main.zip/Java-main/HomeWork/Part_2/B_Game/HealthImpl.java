package HomeWork.Part_2.B_Game;

public interface HealthImpl {
    int getCurrentHealthPoint();
    int getMaxHealthPoint();
}
