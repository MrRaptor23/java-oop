package HomeWork.Part_2.B_Game;

public interface ManaImpl {
    int getCurrentManaPoint();
    int getMaxManaPoint();
}
